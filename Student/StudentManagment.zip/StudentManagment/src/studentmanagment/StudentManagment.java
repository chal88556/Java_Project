
package studentmanagment;


public class StudentManagment {

  
    public static void main(String[] args) {
        new Welcome().setVisible(true);
    }
    
}
